#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-A with Hash Tag Feature Extraction and Maximum Entropy
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist
#Eliminating words with size less than three

import matplotlib.pyplot as plt #used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot #used for plotting graphs
from plotly.graph_objs import *   #used for plotting graphs
import nltk
import collections

#Funtion to read Training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet
    
# Plotting initial SubTask A - Training Data
def plotlabels(positive,neutral,negative):
    datas = [{'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016downloaded4-subtask A.tsv')

#Reading testing data    
testing_data=read_testing_data('twitter-2016devtest-A.txt')
#testing_data=read_testing_data('twitter-2016test-A.txt')

#Calculating the count of sentiment classes in the training data
positive=0;
negative=0;
neutral=0;
posna=0;
negna=0;
neuna=0;

for cols in training_data:
    if cols[1]=="positive":
        if(cols[2])=="Not Available":
            posna=posna+1;
        positive=positive+1;
    elif cols[1]=='neutral':    
        if(cols[2])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[1]=="negative":
        if(cols[2])=="Not Available":
            negna=negna+1;
        negative=negative+1;
        
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(positive,neutral,negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;

trace0 = Bar(
    x=['positive','neutral','negative'],
    y=[pos_tweet,neu_tweet,neg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['positive','neutral','negative'],
    y=[posna,neuna,negna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph.html') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[2]!="Not Available":
        actual_training_data.append(cols)

#recalculating the counts of sentiment classes
positive=0;
negative=0;
neutral=0;
for cols in actual_training_data:
    if cols[1]=="positive":
          positive=positive+1;
    elif cols[1]=="neutral":
          neutral=neutral+1;
    elif cols[1]=="negative":
          negative=negative+1;

#plotting the actual positive and negative classes of training data
plotlabels(positive,neutral,negative);

#Reading the training data from file    
sentences=[]
sentiment=[]
tweets=[]
for cols in actual_training_data:
    sentences.append(cols[2])
    sentiment.append(cols[1])
    tweets.append((cols[2],cols[1]))

#Reading the testing data from file    
sentencesTest=[]
sentimentTest=[]
testtweets=[]
for testcols in testing_data:
    sentencesTest.append(testcols[2])
    sentimentTest.append(testcols[1])
    testtweets.append((testcols[2],testcols[1]))

#Function to Seperate Hash Words from data
def hash_tag_removal(word):
    for i in word:
        if(i=="#"):
           word=word.replace(i,'')
    return word

#Extracting only hash tag words for training data
hash_words=[]
hash_word=[]
for i in range(len(tweets)):
    hash_word.append([hash_tag_removal(j) for j in tweets[i][0].split() if j.startswith("#")])
for i in range(len(hash_word)):
    for j in range(len(hash_word[i])):
        hash_words.append([hash_word[i][j],sentiment[i]])
        
#Extracting only hash tag words for testing data
hash_words_test=[]
hash_word_test=[]
for i in range(len(testtweets)):
    hash_word_test.append([hash_tag_removal(j) for j in testtweets[i][0].split() if j.startswith("#")])
for i in range(len(hash_word_test)):
    for j in range(len(hash_word_test[i])):
        hash_words_test.append([hash_word_test[i][j],sentimentTest[i]])

# Function to get all words from hash tags
def get_words_from_tweets(hash_words):
    all_words=[]
    for i in range(len(hash_words)):
        all_words.append(hash_words[i][0])
    return all_words

#Calling to fetch all the words from the hashtags
words_list=get_words_from_tweets(hash_words)

#Funtion to count the word frequency and building Hashtag words dictionary
def get_word_freq(words_list):
    worddict=nltk.FreqDist(words_list)
    return worddict

word_dict=get_word_freq(words_list)

#Listing all words from the hashtag words dictionary
word_features=word_dict.keys()

#Extracting relevant features
def extract_features(tweets):
    features={}
    for word in word_features:
       features['contains(%s)' %word]=word in tweets
    return features

#Modelling the classifier 
training_set=nltk.classify.apply_features(extract_features,hash_words)
classifier=nltk.MaxentClassifier.train(training_set,max_iter=1) 

#Testing the classifier
testing_set=nltk.classify.apply_features(extract_features,hash_words_test)
accuracy=nltk.classify.accuracy(classifier,testing_set)

#Perfomance Metrics
accuracy=nltk.classify.accuracy(classifier,testing_set)
actual = collections.defaultdict(set)
predicted = collections.defaultdict(set)
actual_label=[]
predicted_label=[]
recall_values_topicwise=[]
f1score_values_topicwise=[]
for i, (feats, label) in enumerate(testing_set):
    actual[label].add(i)
    observed = classifier.classify(feats)
    predicted[observed].add(i)
    actual_label.append(label)
    predicted_label.append(observed)
    conf_matrix=nltk.ConfusionMatrix(actual_label,predicted_label)
    class_values=actual.keys()
for i in class_values:
    if(nltk.recall(actual[str(i)],predicted[str(i)]) is None):
        recall_values_topicwise.append(0) 
    else:
        recall_values_topicwise.append(nltk.recall(actual[str(i)],predicted[str(i)]))
    if(nltk.f_measure(actual[str(i)],predicted[str(i)]) is None):
        f1score_values_topicwise.append(0)
    else:
        f1score_values_topicwise.append(nltk.f_measure(actual[str(i)],predicted[str(i)]))
MAR_macro_average=(sum(recall_values_topicwise)/len(class_values));
F1_macro_average=(sum(f1score_values_topicwise)/len(class_values));
NB_Accuracy=accuracy;
print("SubTask-A Topic Averaged Accuracy for Naive Bayes with HashTag emotions is :",NB_Accuracy )
print("Subtask-A Macro Averaged Recall for Naive Bayes with HashTag emotions is :",MAR_macro_average)  
print("Subtask-A Macro Averaged F1-Measure for Naive Bayes with HashTag emotions is :",F1_macro_average)