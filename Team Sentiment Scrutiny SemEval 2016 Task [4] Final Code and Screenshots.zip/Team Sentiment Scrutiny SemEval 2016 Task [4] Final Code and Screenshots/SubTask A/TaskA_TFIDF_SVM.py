#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-A with TFIDF Feature vectoriser and SVM Linear,RBF Kernel and SVC Linear
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist

import matplotlib.pyplot as plt # used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot # used for plotting graphs
from plotly.graph_objs import *   # used for plotting graphs
import re # used for pre-processing 
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
from sklearn.feature_extraction.text import TfidfVectorizer # used for TF-IDF vector generation
import numpy as np # used for columnstack
import pandas as pd # used for dataframe constuction
import time # used to calculate time of the classification
from sklearn import svm # used to invoke classifier
from sklearn.metrics import accuracy_score # used for accuracy score calculation
from sklearn.metrics import recall_score # used for macro average recall calculation
from sklearn.metrics import f1_score #used for f1-score

#Function to read training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet

# Plotting initial SubTask A - Training Data
def plotlabels(positive,neutral,negative):
    datas = [{'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative}
            ]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data= read_training_data('2016downloaded4-subtask A.tsv')

#Reading testing data    
#testing_data=read_testing_data('twitter-2016devtest-A.txt')
testing_data=read_testing_data('twitter-2016test-A.txt')

#Calculating the count of sentiment classes in the training data
positive=0;
negative=0;
neutral=0;
posna=0;
neuna=0;
negna=0;

for cols in training_data:
    if cols[1]== 'positive':
        if(cols[2])=="Not Available":
            posna=posna+1;
        positive=positive+1;
    elif cols[1]=='neutral':    
        if(cols[2])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[1]== 'negative':
        if(cols[2])=="Not Available":
            negna=negna+1;
        negative=negative+1;
    
#Calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(positive,neutral,negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;

trace0 = Bar(
    x=['positive','neutral','negative'],
    y=[pos_tweet,neu_tweet,neg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['positive','neutral','negative'],
    y=[posna,neuna,negna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph.html') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[2]!="Not Available":
        actual_training_data.append(cols)
positive=0;
negative=0;
neutral=0;

for cols in actual_training_data:
    if cols[1]=="positive":
          positive=positive+1;
    elif cols[1]=="neutral":
        neutral=neutral+1;
    elif cols[1]=="negative":
          negative=negative+1;
          
#plotting the actual positive and negative classes of training data
plotlabels(positive,neutral,negative);

#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

#Reading the training data from file
sentences=[]
sentiment=[]
for cols in actual_training_data:
    sentences.append(cols[2])
    sentiment.append(cols[1])

#Pre-Processing the training data 
processed_sentences=[]
for i in sentences:   
     processed_sentences.append(preprocessing(i))
tweets=np.column_stack((processed_sentences,sentiment)).tolist()

#Reading the testing data from file
sentencesTest=[]
sentimentTest=[]
for testcols in testing_data:
    sentencesTest.append(testcols[2])
    sentimentTest.append(testcols[1])

#Pre-Processing the testing data 
processed_sentences_test=[]
for i in sentencesTest:   
     processed_sentences_test.append(preprocessing(i))
testtweets=np.column_stack((processed_sentences_test,sentimentTest)).tolist()

#Initialising TF-IDF Vector
Vectorizer = TfidfVectorizer(sublinear_tf=True,use_idf=True)

#Creating dataframe for picking each topic's training and testing data
traintweet_df=pd.DataFrame(tweets)
traintweet_df.columns=['tweet','sentiment']
testtweet_df=pd.DataFrame(testtweets)
testtweet_df.columns=['tweet','sentiment']

#Building training and test vectors
train_vectors = Vectorizer.fit_transform(traintweet_df['tweet'].tolist())
test_vectors = Vectorizer.transform(testtweet_df['tweet'].tolist())

##Classification with SVM Classifier and RBF kernel
classifier_rbf = svm.SVC()
t0 = time.time()
classifier_rbf.fit(train_vectors, traintweet_df['sentiment'].tolist())
t1 = time.time()
prediction_rbf = classifier_rbf.predict(test_vectors)
t2 = time.time()
time_rbf_train = t1-t0
time_rbf_predict = t2-t1
print("SubTask-A Accuracy with SVM RBF Kernel is: %.3f \n" %((accuracy_score(testtweet_df['sentiment'].tolist(),prediction_rbf))))
print("SubTask-A Macro Averaged Recall  with SVM RBF Kernel is: %.3f \n" %((recall_score(testtweet_df['sentiment'].tolist(),prediction_rbf, average='macro'))))
print("SubTask-A F1-Measure with SVM RBF Kernel is: %.3f \n" %((f1_score(testtweet_df['sentiment'].tolist(),prediction_rbf, average='macro'))))
print("Total time taken: %ds" %(time_rbf_train+time_rbf_predict))

##Classification with SVM and kernel is linear
classifier_linear = svm.SVC(kernel='linear')
t0 = time.time()
classifier_linear.fit(train_vectors, traintweet_df['sentiment'].tolist())
t1 = time.time()
prediction_linear = classifier_linear.predict(test_vectors)
t2 = time.time()
time_linear_train = t1-t0
time_linear_predict = t2-t1
print("SubTask-A Accuracy with SVM Linear Kernel is: %.3f \n" %((accuracy_score(testtweet_df['sentiment'].tolist(),prediction_linear))))
print("SubTask-A Macro Averaged Recall  with SVM Linear Kernel is: %.3f \n" %((recall_score(testtweet_df['sentiment'].tolist(),prediction_linear, average='macro'))))
print("SubTask-A F1-Measure with SVM Linear Kernel is: %.3f \n" %((f1_score(testtweet_df['sentiment'].tolist(),prediction_linear, average='macro'))))
print("Total time taken: %ds" %(time_linear_train+time_linear_predict))

##Classification with Linear SVM
classifier_linearsvm = svm.LinearSVC()  
t0 = time.time()
classifier_linearsvm.fit(train_vectors, traintweet_df['sentiment'].tolist())
t1 = time.time()
prediction_linearsvm = classifier_linearsvm.predict(test_vectors)
t2 = time.time()
time_linearsvm_train = t1-t0
time_linearsvm_predict = t2-t1
print("SubTask-A Accuracy with SVM Linear SVC is: %.3f \n" %((accuracy_score(testtweet_df['sentiment'].tolist(),prediction_linearsvm))))
print("SubTask-A Macro Averaged Recall  with SVM Linear SVC is: %.3f \n" %((recall_score(testtweet_df['sentiment'].tolist(),prediction_linearsvm, average='macro'))))
print("SubTask-A F1-Measure with SVM Linear SVC is: %.3f \n" %((f1_score(testtweet_df['sentiment'].tolist(),prediction_linearsvm, average='macro'))))
print("Total time taken: %ds" %(time_linearsvm_train+time_linearsvm_predict))