#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-C with Hash Tag Feature Extraction and Naive Bayes Classifier
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist
#Eliminating words with size less than three

import matplotlib.pyplot as plt #used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot #used for plotting graphs
from plotly.graph_objs import *   #used for plotting graphs
import nltk
import collections
from sklearn.metrics import mean_absolute_error #used for calculating mean absolute error

#Funtion to read Training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet
    
# Plotting initial SubTask C - Training Data
def plotlabels(highlypositive,positive,neutral,negative,highlynegative):
    datas = [{'label':'highly positive', 'color': 'm', 'height': h_positive},
             {'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative},
             {'label':'highly negative', 'color': 'r', 'height': h_negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016subtaskCEtrain.tsv')

#Reading testing data    
#testing_data=read_testing_data('twitter-2016devtest-CE.txt')
testing_data=read_testing_data('twitter-2016test-CE.txt')

#Calculating the count of sentiment classes in the training data
h_positive=0;
positive=0;
negative=0;
neutral=0;
h_negative=0;
hposna=0;
posna=0;
neuna=0;
negna=0;
hnegna=0;

for cols in training_data:
    if cols[2]== '2':
        if(cols[3])=="Not Available":
            hposna=hposna+1;
        h_positive=h_positive+1;
    elif cols[2]=='1':
        if(cols[3])=="Not Available":
            posna=posna+1;
        positive= positive+1;
    elif cols[2]=='0':    
        if(cols[3])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[2]=='-1':
        if(cols[3])=="Not Available":
            negna=negna+1;
        negative=negative+1;
    elif cols[2]== '-2':
        if(cols[3])=="Not Available":
            hnegna=hnegna+1;
        h_negative=h_negative+1;
    
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(h_positive,positive,neutral,negative,h_negative);

pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;
hpos_tweet=h_positive-hposna;
hneg_tweet=h_negative-hnegna;

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
trace0 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hpos_tweet,pos_tweet,neu_tweet,neg_tweet,hneg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto' 
)
trace1 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hposna,posna,neuna,negna,hnegna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[3]!="Not Available":
        actual_training_data.append(cols)
positive=0;
negative=0;
neutral=0;
h_positive = 0;
h_negative = 0;
for cols in actual_training_data:
    if cols[2]=="2":
          h_positive=h_positive+1;
    elif cols[2]=="1":
          positive=positive+1;
    elif cols[2]=="0":
        neutral=neutral+1;
    elif cols[2]=="-1":
          negative=negative+1;
    elif cols[2]=="-2":
          h_negative=h_negative+1;
          
#Reading the training data from file    
sentences=[]
sentiment=[]
topic=[]
tweets=[]
for cols in actual_training_data:
    topic.append(cols[1])
    sentences.append(cols[3])
    sentiment.append(cols[2])
    tweets.append((cols[3],cols[2]))

#Reading the testing data from file    
sentencesTest=[]
sentimentTest=[]
topicTest=[]
testtweets=[]
for testcols in testing_data:
    topicTest.append(testcols[1])
    sentencesTest.append(testcols[3])
    sentimentTest.append(testcols[2])
    testtweets.append((testcols[3],testcols[2]))

#Function to Seperate Hash Words from data
def hash_tag_removal(word):
    for i in word:
        if(i=="#"):
           word=word.replace(i,'')
    return word

#Extracting only hash tag words for training data
hash_words=[]
hash_word=[]
for i in range(len(tweets)):
    hash_word.append([hash_tag_removal(j) for j in tweets[i][0].split() if j.startswith("#")])
for i in range(len(hash_word)):
    for j in range(len(hash_word[i])):
        hash_words.append([hash_word[i][j],sentiment[i]])
        
#Extracting only hash tag words for testing data
hash_words_test=[]
hash_word_test=[]
for i in range(len(testtweets)):
    hash_word_test.append([hash_tag_removal(j) for j in testtweets[i][0].split() if j.startswith("#")])
for i in range(len(hash_word_test)):
    for j in range(len(hash_word_test[i])):
        hash_words_test.append([hash_word_test[i][j],sentimentTest[i]])

# Function to get all words from hash tags
def get_words_from_tweets(hash_words):
    all_words=[]
    for i in range(len(hash_words)):
        all_words.append(hash_words[i][0])
    return all_words

#Calling to fetch all the words from the hashtags
words_list=get_words_from_tweets(hash_words)

#Funtion to count the word frequency and building Hashtag words dictionary
def get_word_freq(words_list):
    worddict=nltk.FreqDist(words_list)
    return worddict

word_dict=get_word_freq(words_list)

#Listing all words from the hashtag words dictionary
word_features=word_dict.keys()

#Extracting relevant features
def extract_features(tweets):
    features={}
    for word in word_features:
       features['contains(%s)' %word]=word in tweets
    return features

#Modelling the classifier 
training_set=nltk.classify.apply_features(extract_features,hash_words)
classifier=nltk.NaiveBayesClassifier.train(training_set) 
predicted=[]
#Testing the classifier
testing_set=nltk.classify.apply_features(extract_features,hash_words_test)
accuracy=nltk.classify.accuracy(classifier,testing_set)

#Perfomance Metrics
actual = collections.defaultdict(set)
predicted = collections.defaultdict(set)
actual_label=[]
predicted_label=[]
recall_values_topicwise=[]
f1score_values_topicwise=[]
true_values_std=[]
prediction_std=[]
prediction_hneg = []   
prediction_neg = []
prediction_neu = []
prediction_pos = []
prediction_hpos = []
true_values_hneg = []
true_values_neg = []
true_values_neu = []
true_values_pos = []
true_values_hpos = []
for i, (feats, label) in enumerate(testing_set):
    print("hi",i)
    print("feats",feats)
    print("label",label)
    actual[label].add(i)
    observed = classifier.classify(feats)
    predicted[observed].add(i)
    actual_label.append(label)
    predicted_label.append(observed)
    conf_matrix=nltk.ConfusionMatrix(actual_label,predicted_label)
    class_values=actual.keys()
for i in class_values:
    #Mean Abosulte Error Macro Calculation
    if (int(i) == -1):
        for index,i in enumerate(actual[str(i)]):
            prediction_neg.append(int(predicted_label[i]))
            true_values_neg.append(int(actual_label[i]))
            prediction_std.append(int(predicted_label[i]))
            true_values_std.append(int(actual_label[i]))
    elif(int(i) == -2):
        for index,i in enumerate(actual[str(i)]):
            prediction_hneg.append(int(predicted_label[i]))
            true_values_hneg.append(int(actual_label[i]))            
            prediction_std.append(int(predicted_label[i]))
            true_values_std.append(int(actual_label[i]))
    elif(int(i) == 0):
        for index,i in enumerate(actual[str(i)]):
            prediction_neu.append(int(predicted_label[i]))
            true_values_neu.append(int(actual_label[i]))
            prediction_std.append(int(predicted_label[i]))
            true_values_std.append(int(actual_label[i]))
    elif(int(i) == 1):
        for index,i in enumerate(actual[str(i)]):
            prediction_pos.append(int(predicted_label[i]))
            true_values_pos.append(int(actual_label[i]))
            prediction_std.append(int(predicted_label[i]))
            true_values_std.append(int(actual_label[i]))
    elif(int(i) == 2):
        for index,i in enumerate(actual[str(i)]):
            prediction_hpos.append(int(predicted_label[i]))
            true_values_hpos.append(int(actual_label[i]))
            prediction_std.append(int(predicted_label[i]))
            true_values_std.append(int(actual_label[i]))
MAE_Standard=mean_absolute_error(true_values_std,prediction_std)
if(len(true_values_neg)!=0):
    MAE_neg = ((mean_absolute_error(true_values_neg,prediction_neg)))
else:
    MAE_neg = 0;
if(len(true_values_hneg)!=0):
    MAE_hneg = ((mean_absolute_error(true_values_hneg,prediction_hneg)))
else:
    MAE_hneg = 0;
if(len(true_values_neu)!=0):
    MAE_neu = ((mean_absolute_error(true_values_neu,prediction_neu)))
else:            
    MAE_neu = 0;
if(len(true_values_pos)!=0):
    MAE_pos = ((mean_absolute_error(true_values_pos,prediction_pos)))
else:
    MAE_pos = 0;
if(len(true_values_hpos)!=0):
    MAE_hpos = ((mean_absolute_error(true_values_hpos,prediction_hpos)))
else:
    MAE_hpos = 0;
test_MAE=(MAE_neg+MAE_hneg+MAE_neu+MAE_pos+MAE_hpos)/len(class_values)
print("Subtask-C Mean Absolute Error - Macro for Naive Bayes with HashTag Feature is :",MAE_Standard)  
print("Subtask-C Mean Absolute Error - Standard for Naive Bayes with HashTag Feature is :",test_MAE)