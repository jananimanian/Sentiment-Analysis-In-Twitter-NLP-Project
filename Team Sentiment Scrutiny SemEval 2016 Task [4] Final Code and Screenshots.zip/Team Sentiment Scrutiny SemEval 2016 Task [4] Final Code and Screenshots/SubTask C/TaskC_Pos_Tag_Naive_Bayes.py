#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-C with POS-TAG Feature and Naive Bayes Classifier
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist
#Eliminating words with size less than three

import matplotlib.pyplot as plt #used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot #used for plotting graphs
from plotly.graph_objs import *   #used for plotting graphs
import re #Used for pre-processing 
import nltk
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
import pandas as pd #used for dataframe constuction
import numpy as np #used for columnstack
import collections #used to collect the set of actual and predicted labels
from sklearn.metrics import mean_absolute_error #used for calculating mean absolute error
from nltk import pos_tag #used for tagging Parts of speech

#Function to read the training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet
 
# Plotting initial SubTask C - Training Data
def plotlabels(highlypositive,positive,neutral,negative,highlynegative):
    datas = [{'label':'highly positive', 'color': 'm', 'height': h_positive},
             {'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative},
             {'label':'highly negative', 'color': 'r', 'height': h_negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016subtaskCEtrain.tsv')

#Reading testing data    
#testing_data=read_testing_data('twitter-2016devtest-CE.txt')
testing_data=read_testing_data('twitter-2016test-CE.txt')

#Calculating the count of sentiment classes in the training data
h_positive=0;
positive=0;
negative=0;
neutral=0;
h_negative=0;
hposna=0;
posna=0;
neuna=0;
negna=0;
hnegna=0;

for cols in training_data:
    if cols[2]== '2':
        if(cols[3])=="Not Available":
            hposna=hposna+1;
        h_positive=h_positive+1;
    elif cols[2]=='1':
        if(cols[3])=="Not Available":
            posna=posna+1;
        positive= positive+1;
    elif cols[2]=='0':    
        if(cols[3])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[2]=='-1':
        if(cols[3])=="Not Available":
            negna=negna+1;
        negative=negative+1;
    elif cols[2]== '-2':
        if(cols[3])=="Not Available":
            hnegna=hnegna+1;
        h_negative=h_negative+1;
    
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(h_positive,positive,neutral,negative,h_negative);

pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;
hpos_tweet=h_positive-hposna;
hneg_tweet=h_negative-hnegna;

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
trace0 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hpos_tweet,pos_tweet,neu_tweet,neg_tweet,hneg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto' 
)
trace1 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hposna,posna,neuna,negna,hnegna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph') 

#Removing the missing tweets and storing the actual tweets for further processing

actual_training_data=[]
for cols in training_data:  
    if cols[3]!="Not Available":
        actual_training_data.append(cols)
positive=0;
negative=0;
neutral=0;
h_positive = 0;
h_negative = 0;
for cols in actual_training_data:
    if cols[2]=="2":
          h_positive=h_positive+1;
    elif cols[2]=="1":
          positive=positive+1;
    elif cols[2]=="0":
        neutral=neutral+1;
    elif cols[2]=="-1":
          negative=negative+1;
    elif cols[2]=="-2":
          h_negative=h_negative+1;

#plotting the actual positive and negative classes of training data  
plotlabels(h_positive,positive,neutral,negative,h_negative);

#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

#Reading the training data from file
tweets=[]
all_words_tags=[]
for cols in actual_training_data:
    tag_sentence=[]
    topic=cols[1];
    sentiment=cols[2];
    sentence=cols[3];
    preprocessed_sentence=preprocessing(sentence)
    #Converting the tweets into lowercase and eliminating words with size less than three
    words_filtered=[e.lower() for e in preprocessed_sentence.split() if len(e) >=3]
    tag_sentence.append((pos_tag(words_filtered)))
    #Storing the words and tags in a list to be used in building model
    for wordstags in tag_sentence:
        all_words_tags.extend(wordstags) 
    tweets.append((topic,tag_sentence,sentiment))
    
#Reading the testing data from file
testtweets=[]
for testcols in testing_data:
    tag_sentence_test=[]
    topicTest=testcols[1];
    sentimentTest=testcols[2];
    sentenceTest=testcols[3];
    preprocessed_sentence_test=preprocessing(sentenceTest)
    #Converting the tweets into lowercase and eliminating words with size less than three
    words_filtered_test=[e.lower() for e in preprocessed_sentence_test.split() if len(e) >=3]
    tag_sentence_test.append((pos_tag(words_filtered_test)))
    testtweets.append((topicTest,tag_sentence_test,sentimentTest))

#Function to build POS Feature dictionary
def get_word_freq(words_list):
    worddict=nltk.FreqDist(words_list)
    return worddict

#Filtering only the required sentiment bearing POS tag 
required_word_tag=[]
for (word,tag) in all_words_tags:
    if(tag=='JJ') or (tag=='JJR') or (tag=='JJS') or (tag=='RB') or (tag=='RBR') or (tag=='RBS') or (tag=='NN') or (tag=='NNS')or (tag=='NNP') or (tag=='NNPS') or (tag=='UH') or (tag=='VB') or (tag=='VBD') or (tag=='VBG') or (tag=='VBN')or (tag=='VBP') or (tag=='VBZ'):
        required_word_tag.append((word,tag))

#Storing the POS Feature Dictionary
word_dict=get_word_freq(required_word_tag)

#Listing all unique POS tagged words
word_postag=word_dict.keys()

# Extracting Required features by cross chcking with POS Feature dictionary
def extract_features(tweets):
    wordtag=[] #to fetch the word and tag tuple from input argument tweets    
    features={} # feature array variable
    for wordstags in tweets: #seperating the word and tag tuples into a list
        wordtag.extend(wordstags)
    matched=0;
    for i in word_postag:
        for j in wordtag:
            (a,b)=([(a == b) for a, b in zip(i,j)])
            if(a==True) and (b==True):
                matched=1
                break
            else:
                matched=0
        if(matched==1):
            features['contains(%s,%s)' %(i)]=True # setting features array to true if the combination is present in our POS Feature dictionary
        else:
            features['contains(%s,%s)' %(i)]=False # setting features array to False if the combination is not present in our POS Feature dictionary              
    return features

#Creating dataframe for picking each topic's training and testing data
traintweet_df=pd.DataFrame(tweets)
traintweet_df.columns=['topic','tweet','sentiment']
testtweet_df=pd.DataFrame(testtweets)
testtweet_df.columns=['topic','tweet','sentiment']

#Modelling the classifier with training data
tweet_senti_pertopic=np.column_stack((traintweet_df['tweet'],traintweet_df['sentiment'])).tolist()
training_set=nltk.classify.apply_features(extract_features,tweet_senti_pertopic)
classifier=nltk.NaiveBayesClassifier.train(training_set)

test_accuracy=0
test_topic_count=0
test_MAE=[]
test_MAE_Standard=[]

#Testing the classifier with testing data with respect to topic
test_tweets_per_topic=testtweet_df.groupby('topic')
for testcols in test_tweets_per_topic:
    MAE_Standard=[]
    prediction_hneg = []
    prediction_neg = []
    prediction_neu = []
    prediction_pos = []
    prediction_hpos = []
    true_values_hneg = []
    true_values_neg = []
    true_values_neu = []
    true_values_pos = []
    true_values_hpos = []   
    test_topic_count=test_topic_count+1
    print("test_topic_count",test_topic_count)
    topicwise_test_df=testcols[1]
    tweet_senti_test_pertopic=np.column_stack((topicwise_test_df['tweet'],topicwise_test_df['sentiment'])).tolist()
    testing_set=nltk.classify.apply_features(extract_features,tweet_senti_test_pertopic)
    accuracy=nltk.classify.accuracy(classifier,testing_set)
    test_accuracy=test_accuracy+accuracy
    print("Test accuracy for the topic ",testcols[0]," is :",accuracy)
    actual = collections.defaultdict(set)
    predicted = collections.defaultdict(set)
    actual_label=[]
    predicted_label=[]
    for i, (feats, label) in enumerate(testing_set):
        actual[label].add(i)
        observed = classifier.classify(feats)
        predicted[observed].add(i)
        actual_label.append(label)
        predicted_label.append(observed)
        conf_matrix=nltk.ConfusionMatrix(actual_label,predicted_label)
        class_values=actual.keys()   
    for i in class_values:
        if(mean_absolute_error(int(actual_label[i]),int(predicted_label[i])) is None):
            MAE_Standard.append(0)
        else:
            MAE_Standard.append((mean_absolute_error(int(actual_label[i]),int(predicted_label[i]))))        
        #Mean Abosulte Error Macro Calculation
        if (int(i) == -1):
            for index,i in enumerate(actual[str(i)]):
                prediction_neg.append(int(predicted_label[i]))
                true_values_neg.append(int(actual_label[i]))
        elif(int(i) == -2):
            for index,i in enumerate(actual[str(i)]):
                prediction_hneg.append(int(predicted_label[i]))
                true_values_hneg.append(int(actual_label[i]))            
        elif(int(i) == 0):
            for index,i in enumerate(actual[str(i)]):
                prediction_neu.append(int(predicted_label[i]))
                true_values_neu.append(int(actual_label[i]))        
        elif(int(i) == 1):
            for index,i in enumerate(actual[str(i)]):
                prediction_pos.append(int(predicted_label[i]))
                true_values_pos.append(int(actual_label[i]))        
        elif(int(i) == 2):
            for index,i in enumerate(actual[str(i)]):
                prediction_hpos.append(int(predicted_label[i]))
                true_values_hpos.append(int(actual_label[i]))
    if(len(true_values_neg)!=0):
        MAE_neg = ((mean_absolute_error(true_values_neg,prediction_neg)))
    else:
        MAE_neg = 0;
    if(len(true_values_hneg)!=0):
        MAE_hneg = ((mean_absolute_error(true_values_hneg,prediction_hneg)))
    else:
        MAE_hneg = 0;
    if(len(true_values_neu)!=0):
        MAE_neu = ((mean_absolute_error(true_values_neu,prediction_neu)))
    else:            
        MAE_neu = 0;
    if(len(true_values_pos)!=0):
        MAE_pos = ((mean_absolute_error(true_values_pos,prediction_pos)))
    else:
        MAE_pos = 0;
    if(len(true_values_hpos)!=0):
        MAE_hpos = ((mean_absolute_error(true_values_hpos,prediction_hpos)))
    else:
        MAE_hpos = 0;
    test_MAE_Standard.append(sum(MAE_Standard)/len(class_values))
    print("Mean Absolute Error-Standard for topic ",testcols[0]," is :",test_MAE_Standard)
    test_MAE.append((MAE_neg+MAE_hneg+MAE_neu+MAE_pos+MAE_hpos)/len(class_values))
    print("Mean Absolute Error-Macro for topic ",testcols[0]," is :",(MAE_neg+MAE_hneg+MAE_neu+MAE_pos+MAE_hpos)/len(class_values))
    
MAE_macro_average=sum(test_MAE)/test_topic_count;
MAE_standard_average=sum(test_MAE_Standard)/test_topic_count;
print("Subtask-C aean Absolute Error - Macro for Naive Bayes POS-Tags :",MAE_macro_average)  
print("Subtask-C Mean Absolute Error - Standard for Naive Bayes POS-Tags :",MAE_standard_average)