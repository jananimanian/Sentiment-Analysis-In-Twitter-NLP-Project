#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-D - Tweet Quantification - Kullback-Leibler Divergence Calculation
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist

import matplotlib.pyplot as plt # used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot # used for plotting graphs
from plotly.graph_objs import *   # used for plotting graphs
import re # used for pre-processing 
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
from sklearn.feature_extraction.text import TfidfVectorizer # used for TF-IDF vector generation
#from sklearn.model_selection import train_test_split # used for cross validation
import numpy as np # used for columnstack
import pandas as pd # used for dataframe constuction
import time # used to calculate time of the classification
from sklearn import svm # used to invoke classifier
from collections import Counter
import math

# Function to read training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

# Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet

# Plotting initial SubTask D - Training Data
def plotlabels(positive,negative):
    datas = [{'label':'positive', 'color': 'g', 'height': positive},
             {'label':'negative', 'color': 'b', 'height': negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016-part2-subtaskBD.tsv')

#Reading testing data    
testing_data=read_testing_data('twitter-2016devtest-BD.txt')
#testing_data=read_testing_data('twitter-2016test-BD.txt')

#Calculating the count of sentiment classes in the training data
positive=0;
negative=0;
posna=0;
negna=0;

for cols in training_data:
    if cols[2]=="positive":
        if(cols[3])=="Not Available":
            posna=posna+1;
        positive=positive+1;
    elif cols[2]=="negative":
        if(cols[3])=="Not Available":
            negna=negna+1;
        negative=negative+1;
        
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(positive,negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;

trace0 = Bar(
    x=['positive','negative'],
    y=[pos_tweet,neg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['positive','negative'],
    y=[posna,negna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph.html') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[3]!="Not Available":
        actual_training_data.append(cols)

#recalculating the counts of sentiment classes
positive=0;
negative=0;
for cols in actual_training_data:
    if cols[2]=="positive":
          positive=positive+1;
    elif cols[2]=="negative":
          negative=negative+1;

#plotting the actual positive and negative classes of training data
plotlabels(positive,negative);
#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

#Function to calculate normalized cross-entropy Kullback-Leibler Divergence (KLD)
def KL_Divergence(true, pred):
    epsilon = 0.5 / len(pred)
    countsTrue, countsPred = Counter(true), Counter(pred)
    if(len(countsTrue)==2):
        [actual_pos, actual_neg]=countsTrue.values()
        if(len(countsPred)==2):
            [Predicted_pos, Predicted_neg]=countsPred.values()
        elif(len(countsPred)==1):
            [p_pos_or_p_neg]=countsPred.keys()
            if(p_pos_or_p_neg=="negative"):
                Predicted_pos=1
                [Predicted_neg]=countsPred.values()
            elif(p_pos_or_p_neg=="positive"):
                Predicted_neg=1
                [Predicted_pos]=countsPred.values()               
    elif(len(countsTrue)==1):
        [pos_or_neg]=countsTrue.keys()
        if(pos_or_neg=="negative"):
            [actual_neg]=countsTrue.values()
            actual_pos=1
            if(len(countsPred)==2):
                [Predicted_pos, Predicted_neg]=countsPred.values()
            elif(len(countsPred)==1):
                [p_pos_or_p_neg]=countsPred.keys()
                if(p_pos_or_p_neg=="negative"):
                    Predicted_pos=1
                    [Predicted_neg]=countsPred.values()
                elif(p_pos_or_p_neg=="positive"):
                    Predicted_neg=1
                    [Predicted_pos]=countsPred.values()           
        elif(pos_or_neg=="positive"):
            [actual_pos]=countsTrue.values()
            actual_neg=1
            if(len(countsPred)==2):
                [Predicted_pos, Predicted_neg]=countsPred.values()
            elif(len(countsPred)==1):
                [p_pos_or_p_neg]=countsPred.keys()
                if(p_pos_or_p_neg=="negative"):
                    Predicted_pos=1
                    [Predicted_neg]=countsPred.values()
                elif(p_pos_or_p_neg=="positive"):
                    Predicted_neg=1
                    [Predicted_pos]=countsPred.values()      
    p_positive = actual_pos/len(true)
    p_negative = actual_neg/len(true)
    est_positive = Predicted_pos/len(true)
    est_negative = Predicted_neg/len(true)
    p_positive_s = (p_positive + epsilon)/(p_positive+p_negative+2*epsilon)
    p_negative_s = (p_negative + epsilon)/(p_positive+p_negative+2*epsilon)
    est_positive_s = (est_positive+epsilon)/(est_positive+est_negative+2*epsilon)
    est_negative_s = (est_negative+epsilon)/(est_positive+est_negative+2*epsilon)
    return p_positive_s*math.log10(p_positive_s/est_positive_s)+p_negative_s*math.log10(p_negative_s/est_negative_s)

#Reading the training data from file
sentences=[]
sentiment=[]
topic=[]
for cols in actual_training_data:
    topic.append(cols[1])
    sentences.append(cols[3])
    sentiment.append(cols[2])
    
#Pre-Processing the training data 
processed_sentences=[]
for i in sentences:   
     processed_sentences.append(preprocessing(i))
tweets=np.column_stack((topic,processed_sentences,sentiment)).tolist()

#Reading the test data from file
sentencesTest=[]
sentimentTest=[]
topicTest=[]
for testcols in testing_data:
    topicTest.append(testcols[1])
    sentencesTest.append(testcols[3])
    sentimentTest.append(testcols[2])

#Pre-Processing the test data 
processed_sentences_test=[]
for i in sentencesTest:   
     processed_sentences_test.append(preprocessing(i))
testtweets=np.column_stack((topicTest,processed_sentences_test,sentimentTest)).tolist()

#Initialising TF-IDF Vector
vectorizer = TfidfVectorizer(sublinear_tf=True,use_idf=True)

#Creating dataframe for picking each topic's training and testing data
traintweet_df=pd.DataFrame(tweets)
traintweet_df.columns=['topic','tweet','sentiment']
testtweet_df=pd.DataFrame(testtweets)
testtweet_df.columns=['topic','tweet','sentiment']
tweets_per_topic=testtweet_df.groupby('topic')

#Modelling the classifier with training data
train_vectors = vectorizer.fit_transform(traintweet_df['tweet'].tolist())
classifier_linearsvm = svm.LinearSVC()  
t0 = time.time()
classifier_linearsvm.fit(train_vectors, traintweet_df['sentiment'].tolist())
t1 = time.time()
test_topic_count=0;
test_accuracy=0;
test_MAR=0;
test_f1score=0;
s=[];
time_rbf_train = t1-t0
print("Modelling Time for a Topic:",cols[0],"\n")
print("Total time taken to train %ds" %(time_rbf_train))
#Testing the classifier with testing data with respect to topic
for testcols in tweets_per_topic:
    test_topic_count=test_topic_count+1
    topicwise_test_df=testcols[1]
    test_vectors = vectorizer.transform(topicwise_test_df['tweet'].tolist())
    prediction_rbf = classifier_linearsvm.predict(test_vectors)
    s.append(KL_Divergence(topicwise_test_df['sentiment'].tolist(),prediction_rbf.tolist()))
    t2 = time.time()
    time_rbf_train = t1-t0
    time_rbf_predict = t2-t1
    print("Prediction Time for a Test Topic:",testcols[0],"\n")
    print("Total time taken to predict %ds" %(time_rbf_predict))

KLD_test_avg=sum(s)/test_topic_count
print("Subtask-D Kullback Leibler Divergence for Topicwise Tweet Distribution is :",KLD_test_avg)       