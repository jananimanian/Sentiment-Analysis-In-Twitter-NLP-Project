#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-A with N-Gram Feature Extraction and Maximum Entropy Classifier
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist
#Eliminating words with size less than three

import matplotlib.pyplot as plt #used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot #used for plotting graphs
from plotly.graph_objs import *   #used for plotting graphs
import re #Used for pre-processing 
import nltk
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
from nltk import ngrams #used to assign ngrams
import collections
import pandas as pd #used for dataframe constuction
import numpy as np #used for columnstack

#Funtion to read Training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet
    
# Plotting initial SubTask A - Training Data
def plotlabels(positive,neutral,negative):
    datas = [{'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016downloaded4-subtask A.tsv')

#Reading testing data    
#testing_data=read_testing_data('twitter-2016devtest-A.txt')
testing_data=read_testing_data('twitter-2016test-A.txt')

#Calculating the count of sentiment classes in the training data
positive=0;
negative=0;
neutral=0;
posna=0;
negna=0;
neuna=0;

for cols in training_data:
    if cols[1]=="positive":
        if(cols[2])=="Not Available":
            posna=posna+1;
        positive=positive+1;
    elif cols[1]=='neutral':    
        if(cols[2])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[1]=="negative":
        if(cols[2])=="Not Available":
            negna=negna+1;
        negative=negative+1;
        
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(positive,neutral,negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;

trace0 = Bar(
    x=['positive','neutral','negative'],
    y=[pos_tweet,neu_tweet,neg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['positive','neutral','negative'],
    y=[posna,neuna,negna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph.html') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[2]!="Not Available":
        actual_training_data.append(cols)

#recalculating the counts of sentiment classes
positive=0;
negative=0;
neutral=0;
for cols in actual_training_data:
    if cols[1]=="positive":
          positive=positive+1;
    elif cols[1]=="neutral":
          neutral=neutral+1;
    elif cols[1]=="negative":
          negative=negative+1;

#plotting the actual positive and negative classes of training data
plotlabels(positive,neutral,negative);
#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

# Setting up the N-Grams Value
n_gram=1;

#Reading the training data from file and do pre-processing
tweets=[]
all_ngrams=[]
for cols in actual_training_data:
    ngram_sentence=[]
    preprocessed_sentence=preprocessing(cols[2])
    words_filtered=[e.lower() for e in preprocessed_sentence.split() if len(e) >=3]
    ngram_sentence.append((list(ngrams((words_filtered),n_gram))))
    #Storing the N-grams in a list to be used in building model
    for wordstags in ngram_sentence:
        all_ngrams.extend(wordstags) 
    tweets.append((ngram_sentence,cols[1]))

#Reading the testing data from file and do pre-processing
testtweets=[]
for testcols in testing_data:
    ngram_sentence_test=[]
    preprocessed_sentence_test=preprocessing(testcols[2])
    words_filtered_test=[e.lower() for e in preprocessed_sentence_test.split() if len(e) >=3]
    ngram_sentence_test.append((list(ngrams((words_filtered_test),n_gram))))
    testtweets.append((ngram_sentence_test,testcols[1]))

#Function to build N-gram Feature dictionary
def get_word_freq(words_list):
    worddict=nltk.FreqDist(words_list)
    return worddict

#Storing the N-gram Feature Dictionary
word_dict=get_word_freq(all_ngrams)

#Listing all unique Bigram words
uniq_ngram=word_dict.keys()

# Extracting Required features Unigram by cross chcking with POS Feature dictionary
def extract_features(tweets):
    #tweets_words=set(tweets)
    features={}
    for word in uniq_ngram:
           features['contains(%s)' %word]=word in tweets
    return features

# Extracting Required features by cross chcking with POS Feature dictionary
def extract_features2(tweets):
    bigram_word=[] #to fetch the bigram tuple from input argument tweets    
    features={} # feature array variable
    for bigram_words in tweets: #seperating the bigram tuples into a list
        bigram_word.extend(bigram_words)
        
    matched=0;
    for i in uniq_ngram:
        for j in bigram_word:
            (a,b)=([(a == b) for a, b in zip(i,j)])
            if(a==True) and (b==True):
                matched=1
                break
            else:
                matched=0
        if(matched==1):
            features['contains(%s,%s)' %(i)]=True # setting features array to true if the combination is present in our POS Feature dictionary
        else:
            features['contains(%s,%s)' %(i)]=False # setting features array to False if the combination is not present in our POS Feature dictionary              
    return features

# Extracting Required features by cross chcking with POS Feature dictionary
def extract_features3(tweets):
    trigram_word=[] #to fetch the trigram tuple from input argument tweets    
    features={} # feature array variable
    for trigram_words in tweets: #seperating the trigram tuples into a list
        trigram_word.extend(trigram_words) 
    matched=0;
    for i in uniq_ngram:
        for j in trigram_word:
            x,y,z=([(a == b) for a, b in zip(i,j)])
            if(x==True) and (y==True) and(z==True):
                matched=1
                break
            else:
                matched=0
        if(matched==1):
            features['contains(%s,%s,%s)' %(i)]=True # setting features array to true if the combination is present in our POS Feature dictionary
        else:
            features['contains(%s,%s,%s)' %(i)]=False # setting features array to False if the combination is not present in our POS Feature dictionary              
    return features

#Creating dataframe for picking each topic's training and testing data
traintweet_df=pd.DataFrame(tweets)
traintweet_df.columns=['tweet','sentiment']
testtweet_df=pd.DataFrame(testtweets)
testtweet_df.columns=['tweet','sentiment']

#Modelling the classifier with training data
tweet_senti_pertopic=np.column_stack((traintweet_df['tweet'],traintweet_df['sentiment'])).tolist()
#This will check every tagged tweet with our buit POS Feature dictionary if the word and tag combination is present or not
if(n_gram==1):
    training_set=nltk.classify.apply_features(extract_features,tweet_senti_pertopic)
elif(n_gram==2):
    training_set=nltk.classify.apply_features(extract_features2,tweet_senti_pertopic)
elif(n_gram==3):
    training_set=nltk.classify.apply_features(extract_features3,tweet_senti_pertopic)
    
#Modelling the classifier
classifier=nltk.MaxentClassifier.train(training_set,max_iter=1) 

#Testing the model to predict the accuracy
tweet_senti_test_pertopic=np.column_stack((testtweet_df['tweet'],testtweet_df['sentiment'])).tolist()
if(n_gram==1):
    testing_set=nltk.classify.apply_features(extract_features,tweet_senti_test_pertopic)
elif(n_gram==2):
    testing_set=nltk.classify.apply_features(extract_features2,tweet_senti_test_pertopic)
elif(n_gram==3):
    testing_set=nltk.classify.apply_features(extract_features3,tweet_senti_test_pertopic)

#Perfomance Metrics
accuracy=nltk.classify.accuracy(classifier,testing_set)
actual = collections.defaultdict(set)
predicted = collections.defaultdict(set)
actual_label=[]
predicted_label=[]
recall_values_topicwise=[]
f1score_values_topicwise=[]
for i, (feats, label) in enumerate(testing_set):
    print("Iteration no ", i)
    actual[label].add(i)
    observed = classifier.classify(feats)
    predicted[observed].add(i)
    actual_label.append(label)
    predicted_label.append(observed)
    conf_matrix=nltk.ConfusionMatrix(actual_label,predicted_label)
    class_values=actual.keys()
for i in class_values:
    if(nltk.recall(actual[str(i)],predicted[str(i)]) is None):
        recall_values_topicwise.append(0) 
    else:
        recall_values_topicwise.append(nltk.recall(actual[str(i)],predicted[str(i)]))
    if(nltk.f_measure(actual[str(i)],predicted[str(i)]) is None):
        f1score_values_topicwise.append(0)
    else:
        f1score_values_topicwise.append(nltk.f_measure(actual[str(i)],predicted[str(i)]))
MAR_macro_average=(sum(recall_values_topicwise)/len(class_values));
F1_macro_average=(sum(f1score_values_topicwise)/len(class_values));
NB_Accuracy=accuracy;
print("SubTask-A Topic Averaged Accuracy for Naive Bayes N-Gram ", n_gram," is :",NB_Accuracy )
print("Subtask-A Macro Averaged Recall for Naive Bayes N-Gram ",n_gram," is :",MAR_macro_average)  
print("Subtask-A Macro Averaged F1-Measure for Naive Bayes Ngram",n_gram," :",F1_macro_average)