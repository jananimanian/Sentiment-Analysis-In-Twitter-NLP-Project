#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-B with Lexicon Based Approach,a Non Machine Learning approach
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist
#Eliminating words with size less than three

import matplotlib.pyplot as plt #used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot #used for plotting graphs
from plotly.graph_objs import *   #used for plotting graphs
import re #Used for pre-processing 
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
import pandas as pd #used for dataframe constuction
import numpy as np # used for columnstack
from nltk import pos_tag #used for tagging Parts of speech
from sklearn.metrics import accuracy_score # used for accuracy score calculation
from sklearn.metrics import recall_score # used for macro average recall calculation
from sklearn.metrics import f1_score #used for f1-score

#Function to read data file
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read sentiwordnet file data
def read_testing_data(filename):
    with open(filename,'r') as tgz:
        testTweet = [line.strip().split('\t') for line in tgz]
        return testTweet
# Plotting initial SubTask B - Training Data
def plotlabels(positive,negative):
    datas = [{'label':'positive', 'color': 'g', 'height': positive},
             {'label':'negative', 'color': 'b', 'height': negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
    
#Reading data file     
data_file=read_training_data('twitter-2016devtest-BD.txt')
#data_file=read_testing_data('twitter-2016test-BD.txt')

#Reading Sentiwordnet3.0 file 
wordnet_file=read_training_data('SentiWordNet_3.0.0.tgz')

#Calculating the count of sentiment classes in the training data
positive=0;
negative=0;
posna=0;
negna=0;

for cols in data_file:
    if cols[2]=="positive":
        if(cols[3])=="Not Available":
            posna=posna+1;
        positive=positive+1;
    elif cols[2]=="negative":
        if(cols[3])=="Not Available":
            negna=negna+1;
        negative=negative+1;
        
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(positive,negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;

trace0 = Bar(
    x=['positive','negative'],
    y=[pos_tweet,neg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['positive','negative'],
    y=[posna,negna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph.html') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_data=[]
for cols in data_file:  
    if cols[3]!="Not Available":
        actual_data.append(cols)

#recalculating the counts of sentiment classes
positive=0;
negative=0;
for cols in actual_data:
    if cols[2]=="positive":
          positive=positive+1;
    elif cols[2]=="negative":
          negative=negative+1;

#plotting the actual positive and negative classes of training data
plotlabels(positive,negative);

#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

#Reading the sentiwordnet3.0 data from file
sentiwordlist=[]
sentiwords=[]
for senticols in wordnet_file:
    sentiwords=(senticols[4].split(" "))
    for i in range(len(sentiwords)):
        if ('#' in sentiwords[i]):
            sentiwordtag=[]
            sentiword=sentiwords[i].split('#')
            #sentiwordtag.append((sentiword[0],senticols[0]))
            sentiwordlist.append((sentiword[0],senticols[0],senticols[2],senticols[3]))
            #print("sentiwordlist",sentiwordlist)
            
#Creating dataframe for sentiwordnet words 
wordnet_df=pd.DataFrame(sentiwordlist)
wordnet_df.columns=['words','tags','pos_score','neg_score']

#Reading the data from file
sentences=[]
sentiment=[]
topic=[]
for cols in actual_data:
    topic.append(cols[1])
    sentences.append(cols[3])
    sentiment.append(cols[2])
    
#Pre-Processing the data 
processed_sentences=[]
for i in sentences:   
     processed_sentences.append(preprocessing(i))
tweets=np.column_stack((topic,processed_sentences,sentiment)).tolist()


#Creating a dataframe for the actual data file
actual_data_df=pd.DataFrame(tweets)
actual_data_df.columns=['topic','tweet','sentiment']
actual_data_per_topic=actual_data_df.groupby('topic')

#Lexicon score assignment based on sentiwordnet3.0
topic_count=0;
topic_accuarcy=0;
topic_MAR=0;
topic_F1_measure=0;
for cols in actual_data_per_topic:
    actual_classes=[]
    predicted_classes=[]
    topic_count=topic_count+1
    print("topic_count is ",topic_count)
    topicwise_df=cols[1]
    actual_classes.extend(topicwise_df['sentiment'].tolist())
    preprocessed_sentence=topicwise_df['tweet'].tolist()
    for i in range(len(preprocessed_sentence)):
        tag_sentence=[]
        reqtag_sentence=[]
        words_filtered=[e.lower() for e in str(preprocessed_sentence).split() if len(e) >=2]
        tag_sentence.extend((pos_tag(words_filtered)))
        for (word,tag) in tag_sentence:
            if(word=='no'):
                reqtag_sentence.append((word,'r'))
            elif(tag=='JJ') or (tag=='JJR') or (tag=='JJS'):
                reqtag_sentence.append((word,'a'))
            elif(tag=='RB') or (tag=='RBR') or (tag=='RBS'):
                reqtag_sentence.append((word,'r'))
            elif(tag=='NN') or (tag=='NNS')or (tag=='NNP') or (tag=='NNPS'):
                reqtag_sentence.append((word,'n'))
            elif(tag=='VB') or (tag=='VBD') or (tag=='VBG') or (tag=='VBN')or (tag=='VBP') or (tag=='VBZ'):
                reqtag_sentence.append((word,'v'))
        reqtag_sentence_df=pd.DataFrame(reqtag_sentence)
        reqtag_sentence_df.columns=['words','tags']
        local_df=wordnet_df.merge(reqtag_sentence_df)
        local_df.columns=['words','tags','pos_score','neg_score']
        tweet_df=local_df.drop_duplicates(subset=['words','tags','pos_score','neg_score'])
        tweet_df.columns=['words','tags','pos_score','neg_score']
        pos_score=[]
        neg_score=[]
        pos_score=tweet_df['pos_score']
        neg_score=tweet_df['neg_score']
        pos_score_sum=sum(map(float,pos_score))
        neg_score_sum=sum(map(float,neg_score)) 
        obj_score=1-(pos_score_sum+neg_score_sum)
        if(pos_score_sum>neg_score_sum):
            predicted_classes.append('positive')         
        else:
            predicted_classes.append('negative')
    accuracy=((accuracy_score(actual_classes,predicted_classes)))
    MAR = ((recall_score(actual_classes,predicted_classes,average='macro')))
    f1score = ((f1_score(actual_classes,predicted_classes,average='macro')))
    topic_accuarcy=topic_accuarcy+accuracy
    topic_MAR=topic_MAR+MAR
    topic_F1_measure=topic_F1_measure+f1score
    
#Performance Measures
final_accuracy_score=topic_accuarcy/topic_count;
final_MAR=topic_MAR/topic_count;
final_F1_measure=topic_F1_measure/topic_count;
print("SubTask-B topic wise Accuracy for Lexicon POS approach is: ",final_accuracy_score)
print("SubTask-B topic wise Macro Averaged Recall for Lexicon POS approach is: ",final_MAR)
print("SubTask-B topic wise F1-Score for Lexicon POS approach is: ",final_F1_measure)  