#Team Sentiment Scrutiny: SemEval 2017 Task [4]
#Subramaniyan Janani M12484583
#Venkataramanan Archana M12511297
#Vemparala Sahithi M12484014
#Murali Nithya M12485228
# Subtask-E -Tweet Quantification - Earth Mover's Distance to identify distribution of classes
# using the following preprocessing techniques
#Removing URLs
#Escaping HTML characters
#Contractions Removal 
#Remove special characters
#TweetTokenizer
#TreebankTokenizer
#Emoticons to sentiments
#Stoplist

import matplotlib.pyplot as plt # used for plotting graphs
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot # used for plotting graphs
from plotly.graph_objs import *   # used for plotting graphs
import re # used for pre-processing 
from nltk.tokenize import TweetTokenizer # used for tokenization
from html.parser import HTMLParser # used to remove the html tags
from nltk.tokenize import TreebankWordTokenizer #used for tokenization
from sklearn.feature_extraction.text import TfidfVectorizer # used for TF-IDF vector generation
import numpy as np # used for columnstack
import pandas as pd # used for dataframe constuction
import time # used to calculate time of the classification
from sklearn import svm # used to invoke classifier
from collections import Counter

#Function to read training data
def read_training_data(filename):
    with open(filename,'r') as tsv:
        trainTweet = [line.strip().split('\t') for line in tsv]
        return trainTweet

#Function to read testing data
def read_testing_data(filename):
    with open(filename,'r') as txt:
        testTweet = [line.strip().split('\t') for line in txt]
        return testTweet
    
# Plotting initial SubTask E - Training Data
def plotlabels(highlypositive,positive,neutral,negative,highlynegative):
    datas = [{'label':'highly positive', 'color': 'm', 'height': h_positive},
             {'label':'positive', 'color': 'g', 'height': positive},
             {'label':'neutral', 'color': 'y', 'height': neutral},
             {'label':'negative', 'color': 'b', 'height': negative},
             {'label':'highly negative', 'color': 'r', 'height': h_negative}]
    i = 0
    for data in datas:
        plt.bar(i, data['height'],align='center',color=data['color'])
        i += 1
    labels = [data['label'] for data in datas]
    pos = [i for i in range(len(datas)) ]
    plt.xticks(pos, labels)
    plt.xlabel('Emotions')
    plt.title('Sentiment Analysis')
    plt.show();
    
#Reading training data    
training_data=read_training_data('2016subtaskCEtrain.tsv')

#Reading testing data    
#testing_data=read_testing_data('twitter-2016devtest-CE.txt')
testing_data=read_testing_data('twitter-2016test-CE.txt')

#Calculating the count of sentiment classes in the training data
h_positive=0;
positive=0;
negative=0;
neutral=0;
h_negative=0;
hposna=0;
posna=0;
neuna=0;
negna=0;
hnegna=0;

for cols in training_data:
    if cols[2]== '2':
        if(cols[3])=="Not Available":
            hposna=hposna+1;
        h_positive=h_positive+1;
    elif cols[2]=='1':
        if(cols[3])=="Not Available":
            posna=posna+1;
        positive= positive+1;
    elif cols[2]=='0':    
        if(cols[3])=="Not Available":
            neuna=neuna+1;
        neutral=neutral+1;
    elif cols[2]=='-1':
        if(cols[3])=="Not Available":
            negna=negna+1;
        negative=negative+1;
    elif cols[2]== '-2':
        if(cols[3])=="Not Available":
            hnegna=hnegna+1;
        h_negative=h_negative+1;
    
#calling plotlabels to plot the given tweet w.r.t sentiment labels
plotlabels(h_positive,positive,neutral,negative,h_negative);

#plotting to visuvalise the count of "Not Available" tweets Vs Actual Tweets 
pos_tweet=positive-posna;
neg_tweet=negative-negna;
neu_tweet=neutral-neuna;
hpos_tweet=h_positive-hposna;
hneg_tweet=h_negative-hnegna;

trace0 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hpos_tweet,pos_tweet,neu_tweet,neg_tweet,hneg_tweet],
    name='Tweets',
    text='Tweets',
    textposition='auto'
    
)
trace1 = Bar(
    x=['highly positive','positive','neutral','negative','highly negative'],
    y=[hposna,posna,neuna,negna,hnegna],
    name='Missing Tweets',
    text='Missing Tweets',
    textposition='auto'  
)
data1 = [trace0,trace1]
layout1 = Layout(
    showlegend=False,
    height=600,
    width=800,
    barmode='stack'
)

fig1 = dict( data=data1, layout=layout1 )
plot(fig1,filename='stacked_graph') 

#Removing the missing tweets and storing the actual tweets for further processing
actual_training_data=[]
for cols in training_data:  
    if cols[3]!="Not Available":
        actual_training_data.append(cols)
positive=0;
negative=0;
neutral=0;
h_positive = 0;
h_negative = 0;
for cols in actual_training_data:
    if cols[2]=="2":
          h_positive=h_positive+1;
    elif cols[2]=="1":
          positive=positive+1;
    elif cols[2]=="0":
        neutral=neutral+1;
    elif cols[2]=="-1":
          negative=negative+1;
    elif cols[2]=="-2":
          h_negative=h_negative+1;

#plotting the actual positive and negative classes of training data
plotlabels(h_positive,positive,neutral,negative,h_negative);

#Defining happy and sad emoticon and its pattern
happyemoticon = { ':)' : 'happy ',
         ':D' : 'happy ',
         ':-D' : 'happy ',
         ':-d' : 'happy ',
         ';p' : 'happy ',
         ':p' : 'happy ',
         ';)' : 'happy ',
         }
sademoticon={ ':(' : 'sad ',
         ':\'(' : 'sad ',
         ':o' : 'sad '
         }
happypattern = re.compile('|'.join( re.escape(emoticon) for emoticon in happyemoticon))
sadpattern = re.compile('|'.join( re.escape(emoticon) for emoticon in sademoticon))

#Funtion to return the correspoding string for the happy emoticon
def emoticonSub(string):
    return happypattern.sub('happy ',string)
#Funtion to return the correspoding string for the sad emoticon
def emotoconSubSad(string):
    return sadpattern.sub('sad ',string)

#Defining stopwords
stopwords_list=["myself",	"ours",	"ourselves",	"you",	"yours",	"yourself",	"yourselves",	"himself",	"she",	"her",	"hers",	"herself",	"its",	"itself",	"they",	"them",	"their",	"theirs",	"themselves",	"what",	"which",	"who",	"whom",	"this",	"that",	"these",	"those",	"are",	"was",	"were",	"been",	"being",	"have",	"has",	"had",	"having",	"does",	"did",	"doing",	"the",	"and",	"but",	"because",	"until",	"while",	"for",	"with",	"about",	"against",	"between",	"into",	"through",	"during",	"before",	"after",	"above",	"below",	"from",	"down",	"out",	"off",	"over",	"under",	"again",	"further",	"then",	"once",	"here",	"there",	"when",	"where",	"why",	"how",	"all",	"any",	"both",	"each",	"few",	"more",	"most",	"other",	"some",	"such",	"only",	"own",	"same",	"than",	"too",	"very",	"can",	"will",	"just",	"don",	"should",	"now"]

#Pre-Processing Function
def preprocessing(original_tweet):
    #1.Converting emoticons to words
    res0a=emoticonSub(original_tweet)
    res0b=emotoconSubSad(res0a)
    #2.Removing URLs
    res1 = re.sub(r"http\S+", "", res0b)
    res1 = re.sub(r"https\S+", "", res1)
    #3.Escaping HTML characters
    html_parser = HTMLParser()
    res2 = html_parser.unescape(res1)
    #4.TreebankTokenizer
    res3=TreebankWordTokenizer().tokenize(res2)
    #5.Contractions Removal  
    Appost_dict={"'s":"is","'re":"are","'ve":"have","n't":"not","d":"had","'ll":"will","'m":"am",}
    transformed=[Appost_dict[word] if word in Appost_dict else word for word in res3]
    res4=" ".join(transformed)
    res5=re.sub(r"[!@#$%^&*()_+-=:;?/~`'’]",' ',res4)
    #6.Tweet tokenizer
    tkznr=TweetTokenizer(reduce_len=True,strip_handles=True,preserve_case=False)
    res6=tkznr.tokenize(res5)
    #7.Stopwords Removal
    remove_stopwords=[word for word in res6 if word not in stopwords_list]
    res7= " ".join(remove_stopwords)
    corrected_tweet=res7
    return corrected_tweet

#Function to calculate Earth_Movers_Distance to identify the distribution of tweets across classes
def Earth_Movers_Distance(true, pred):
    Actual_cls=[0,0,0,0,0]
    Predicted_cls=[0,0,0,0,0]
    countsTrue, countsPred = Counter(true), Counter(pred)
    Actual_cls_int=dict((int(k),int(v)) for k,v in countsTrue.items())
    for k in Actual_cls_int:
        Actual_cls[k]=Actual_cls_int[k]   
    Predict_cls_int=dict((int(k),int(v)) for k,v in countsPred.items())
    for k in Predict_cls_int:
        Predicted_cls[k]=Predict_cls_int[k]
    p_positive = Actual_cls[1]/len(true)
    p_highlypositive = Actual_cls[2]/len(true)
    neutral=Actual_cls[0]/len(true)
    n_negative=Actual_cls[-1]/len(true)
    n_highlynegative=Actual_cls[-2]/len(true)
    est_positive = Predicted_cls[1]/len(pred)
    est_highlypositive= Predicted_cls[2]/len(pred)
    est_neutral= Predicted_cls[0]/len(pred)
    est_highlynegative= Predicted_cls[-2]/len(pred)
    est_negative =  Predicted_cls[-1]/len(pred)
    diff_hneg=abs(est_highlynegative-n_highlynegative)
    diff_neg=abs(est_negative-n_negative)
    diff_pos=abs(est_positive-p_positive)
    diff_hpos=abs(est_highlypositive-p_highlypositive)
    diff_neu=abs(est_neutral-neutral)
    emd_value=diff_hneg+diff_neg+diff_hpos+diff_pos+diff_neu;
    return emd_value

#Reading the training data from file
sentences=[]
sentiment=[]
topic=[]
for cols in actual_training_data:
    topic.append(cols[1])
    sentences.append(cols[3])
    sentiment.append(cols[2])

#Pre-Processing the training data 
processed_sentences=[]
for i in sentences:   
     processed_sentences.append(preprocessing(i))
tweets=np.column_stack((topic,processed_sentences,sentiment)).tolist()

#Reading the testing data from file
sentencesTest=[]
sentimentTest=[]
topicTest=[]
for cols in testing_data:
    topicTest.append(cols[1])
    sentencesTest.append(cols[3])
    sentimentTest.append(cols[2])

#Pre-Processing the testing data 
processed_sentences_test=[]
for i in sentencesTest:   
     processed_sentences_test.append(preprocessing(i))
testtweets=np.column_stack((topicTest,processed_sentences_test,sentimentTest)).tolist()

#Initialising TF-IDF Vector
vectorizer = TfidfVectorizer(sublinear_tf=True,use_idf=True)

#Creating dataframe for picking each topic's training and testing data
traintweet_df=pd.DataFrame(tweets)
traintweet_df.columns=['topic','tweet','sentiment']
testtweet_df=pd.DataFrame(testtweets)
testtweet_df.columns=['topic','tweet','sentiment']
tweets_per_topic=testtweet_df.groupby('topic')
train_vectors = vectorizer.fit_transform(traintweet_df['tweet'].tolist())
##Classification with SVM and kernel is linear
classifier_rbf = svm.SVC()
t0 = time.time()
classifier_rbf.fit(train_vectors, traintweet_df['sentiment'].tolist())
t1 = time.time()
test_topic_count=0;
s=[]
time_rbf_train = t1-t0
print("Modelling Time for a Topic:",cols[0],"\n")
print("Total time taken to train %ds" %(time_rbf_train))
#Testing the classifier with testing data with respect to topic
for testcols in tweets_per_topic:
    print("Test topic name",testcols[0])
    test_topic_count=test_topic_count+1
    topicwise_test_df=testcols[1]
    test_vectors = vectorizer.transform(topicwise_test_df['tweet'].tolist())
    prediction_rbf = classifier_rbf.predict(test_vectors)
    s.append(Earth_Movers_Distance(topicwise_test_df['sentiment'].tolist(),prediction_rbf.tolist()))
    t2 = time.time()
    time_rbf_train = t1-t0
    time_rbf_predict = t2-t1
    
SVM_EMD_Value=sum(s)/test_topic_count;
print("Subtask-E Earth Mover's Distance for Topicwise Tweet Distribution using SVM Linear Kernel using RBF Kernel is :",SVM_EMD_Value)